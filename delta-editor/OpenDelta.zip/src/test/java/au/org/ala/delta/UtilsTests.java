package au.org.ala.delta;

import au.org.ala.delta.util.Utils;
import junit.framework.TestCase;

public class UtilsTests extends TestCase {

	public void testLOWORD() {
		int dword = 0xffffeeee;
		short word = Utils.LOWORD(dword);
		assertEquals(word, (short) 0xeeee);
	}
	
	public void testHIWORD() {
		int dword = 0xffffeeee;
		short word = Utils.HIWORD(dword);
		assertEquals(word, (short) 0xffff);		
	}
	
	public void testRTFToANSI() {
		String testString = "\\i Agrostis\\i0  <L.>";
		String expected = "Agrostis <L.>";
		String actual = Utils.RTFToANSI(testString);		
		assertEquals(expected, actual);
	}
	
	public void testStrtol1() {
		String test = "123";
		int expected = 123;
		int actual = Utils.strtol(test);
		assertEquals(expected, actual);
	}
	
	public void testStrtol2() {
		String test = "123abc";
		int expected = 123;
		int actual = Utils.strtol(test);
		assertEquals(expected, actual);
	}
	public void testStrtol3() {
		String test = "abc";
		int expected = 0;
		int actual = Utils.strtol(test);
		assertEquals(expected, actual);
	}
	
	

}
