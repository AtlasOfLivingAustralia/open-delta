package au.org.ala.delta;

import au.org.ala.delta.directives.Show;
import junit.framework.TestCase;

public class DeltaContextTests extends TestCase {
	
	public void testVars() {
		DeltaContext context = new DeltaContext();
		Show s = new Show();
		s.process(context, "This time #TIME and #DATE");		
	}
	
	

}
