package au.org.ala.delta.model;

public class UnorderedMultiStateCharacter extends MultiStateCharacter {

	public UnorderedMultiStateCharacter(int number) {
		super(number);
	}

}
