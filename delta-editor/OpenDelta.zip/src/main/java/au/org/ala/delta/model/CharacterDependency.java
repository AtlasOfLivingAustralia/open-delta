package au.org.ala.delta.model;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

public class CharacterDependency {

	private int _controllingCharacterId;
	private int _dependentCharacterId;
	private Set<Integer> _states = new HashSet<Integer>();

	public CharacterDependency(int controllingCharacterId, Set<Integer> states, int dependentCharacterId) {
		_controllingCharacterId = controllingCharacterId;
		_dependentCharacterId = dependentCharacterId;
		_states = states;
	}

	public int getControllingCharacterId() {
		return _controllingCharacterId;
	}

	public int getDependentCharacterId() {
		return _dependentCharacterId;
	}

	public void addStateValueId(int stateId) {
		_states.add(stateId);
	}

	public Set<Integer> getStates() {
		return _states;
	}

	@Override
	public String toString() {
		String states = StringUtils.join(_states, ", ");
		return String.format("Char. %d controls char. %d for states [%s]", _controllingCharacterId, _dependentCharacterId, states);
	}
}
