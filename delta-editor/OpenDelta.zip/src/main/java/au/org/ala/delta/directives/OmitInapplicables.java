package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class OmitInapplicables extends Directive {
	
	public OmitInapplicables() {
		super("omit", "inapplicables");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		context.setOmitInapplicables(true);
	}

}
