package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class OmitTypeSettingMarks extends Directive {
	
	public OmitTypeSettingMarks() {
		super("omit", "typesetting", "marks");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		Logger.debug("Omitting type setting marks");
		context.setOmitTypeSettingMarks(true);
	}

}
