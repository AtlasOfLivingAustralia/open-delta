package au.org.ala.delta.slotfile;

public class FileHeader implements IOObject {

	public static final int SIZE = 4; // 4 bytes to store a 32 bit number

	public int SysDataPtr;

	public FileHeader() {
		SysDataPtr = FileSignature.SIZE + FileHeader.SIZE;
	}

	@Override
	public void read(BinFile file) {
		SysDataPtr = file.readInt();
	}

	@Override
	public void write(BinFile file) {
		file.writeInt(SysDataPtr);		
	}
	
}
