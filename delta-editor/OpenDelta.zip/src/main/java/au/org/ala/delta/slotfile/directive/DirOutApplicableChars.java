package au.org.ala.delta.slotfile.directive;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class DirOutApplicableChars implements DirectiveFunctor {

	@Override
	public void process(DirectiveInOutState state) {
		throw new NotImplementedException();
	}

}
