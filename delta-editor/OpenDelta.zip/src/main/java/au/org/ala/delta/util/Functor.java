package au.org.ala.delta.util;

import au.org.ala.delta.DeltaContext;

public interface Functor {
	
	Object invoke(DeltaContext context);

}
