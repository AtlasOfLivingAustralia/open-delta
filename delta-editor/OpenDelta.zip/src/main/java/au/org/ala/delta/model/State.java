package au.org.ala.delta.model;

public class State {

}
