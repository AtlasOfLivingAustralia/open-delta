package au.org.ala.delta.model;

import java.util.ArrayList;
import java.util.List;

public abstract class Character {
	
	private int _number;
	private List<CharacterDependency> _dependentCharacters = new ArrayList<CharacterDependency>();
	private boolean _mandatory;
	private boolean _exclusive;
	private String _description;
	private String _notes;
	
	public Character(int number) {
		_number = number;
	}
	
	public int getCharacterId() {
		return _number;
	}
	
	public String getDescription() {
		return _description;
	}
	
	public void setDescription(String desc) {
		_description = desc;
	}
	
	public void addDependentCharacter(CharacterDependency dependency) {
		_dependentCharacters.add(dependency);
	}
	
	public List<CharacterDependency> getDependentCharacters() {
		return _dependentCharacters;
	}
	
	public void setMandatory(boolean b) {
		_mandatory = b;
	}
	
	public boolean isMandatory() {
		return _mandatory;
	}
	
	public void setExclusive(boolean exclusive) {
		_exclusive = exclusive;
	}
	
	public boolean isExclusive() {
		return _exclusive;
	}
	
	public void setNotes(String notes) {
		_notes = notes;
	}
	
	public String getNotes() {
		return _notes;
	}
	
	@Override
	public String toString() {
		return _description;
	}
	
}
