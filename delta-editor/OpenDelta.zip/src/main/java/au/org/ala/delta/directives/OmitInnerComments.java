package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class OmitInnerComments extends Directive {
	
	public OmitInnerComments() {
		super("omit", "inner", "comments");		
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		context.setOmitInnerComments(true);
	}

}
