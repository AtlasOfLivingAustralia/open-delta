package au.org.ala.delta.editor.controller;

import java.awt.event.ActionListener;
import java.net.URL;

import javax.help.CSH;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.help.HelpSetException;

public class HelpController {

	private HelpBroker helpBroker;
	
	public HelpController() {
		try {
			initialiseHelpSet("help/delta_editor/DeltaEditor");
		}
		catch (HelpSetException h) {
			throw new RuntimeException(h);
		}
	}
	
	
	public void initialiseHelpSet(String name) throws HelpSetException {
		URL url = HelpSet.findHelpSet(getClass().getClassLoader(), name);
		HelpSet editorHelpSet = new HelpSet(getClass().getClassLoader(), url);
		
		helpBroker = editorHelpSet.createHelpBroker();
		
	}
	
	public ActionListener helpAction() {
		return new CSH.DisplayHelpFromSource(helpBroker);
	}
	
}
