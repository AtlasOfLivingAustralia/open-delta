package au.org.ala.delta.directives;

public class CharacterWeights extends Directive {

	public CharacterWeights() {
		super("character", "weights");
	}

}
