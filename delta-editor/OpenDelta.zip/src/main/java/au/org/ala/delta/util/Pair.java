package au.org.ala.delta.util;

public class Pair<T,K> {
	
	private T _first;
	private K _second;
	
	public Pair(T first, K second) {
		_first = first;
		_second = second;
	}
	
	public T getFirst() {
		return _first;
	}
	
	public K getSecond() {
		return _second;
	}

}
