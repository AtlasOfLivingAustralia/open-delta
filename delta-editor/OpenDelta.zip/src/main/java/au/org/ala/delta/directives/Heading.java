package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class Heading extends Directive {
	
	public Heading() {
		super("heading");
	}
	
	@Override
	public void process(DeltaContext context, String data) {
		String heading = replaceVariables(context, data.trim());
		context.setVariable("heading", heading);
		Logger.log("HEADING: %s", heading);
	}

}
