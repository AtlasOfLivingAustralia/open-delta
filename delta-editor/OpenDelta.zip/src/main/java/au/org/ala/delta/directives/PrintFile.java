package au.org.ala.delta.directives;

import java.io.File;
import java.io.PrintStream;

import au.org.ala.delta.DeltaContext;

public class PrintFile extends Directive {
		
	public PrintFile() {
		super("print", "file");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		String filename = data.trim() + ".new"; // TODO: kill the .new once stable...
		File file = new File(context.getCurrentParsingContext().getFile().getParentFile(), filename);		
		PrintStream stream = new PrintStream(file);
		context.setPrintStream(stream);
	}

}
