package au.org.ala.delta.model;

public class StateValueMatrix {

	private int _characterCount;
	private int _itemCount;
	private StateValue _matrix[][];

	public StateValueMatrix(int characterCount, int itemCount) {
		_characterCount = characterCount;
		_itemCount = itemCount;
		_matrix = new StateValue[characterCount][itemCount];
	}

	public void setValue(int charIndx, int itemIndex, StateValue value) {
		_matrix[charIndx - 1][itemIndex - 1] = value;
	}

	public StateValue getValue(int charIndex, int itemIndex) {
		return _matrix[charIndex - 1][itemIndex - 1];
	}

}
