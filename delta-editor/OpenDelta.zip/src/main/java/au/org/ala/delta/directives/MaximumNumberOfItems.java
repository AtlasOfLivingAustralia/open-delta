package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class MaximumNumberOfItems extends Directive {
	
	public MaximumNumberOfItems() {
		super("maximum", "number", "of", "items");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		Logger.debug("Setting max number of items to %s", data);
		context.setMaximumNumberOfItems(Integer.parseInt(data));
	}

}
