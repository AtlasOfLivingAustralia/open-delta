package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;
import au.org.ala.delta.model.CharacterFactory;
import au.org.ala.delta.model.CharacterType;

public class CharacterTypes extends AbstractCharacterListDirective<CharacterType> {

	public CharacterTypes() {
		super("character", "types");
	}

	@Override
	protected CharacterType interpretRHS(DeltaContext context, String rhs) {
		return CharacterType.parse(rhs);
	}

	@Override
	protected void processCharacter(DeltaContext context, int charIndex, CharacterType rhs) {
		Logger.debug("Setting type for character %d to %s", charIndex, rhs);
		au.org.ala.delta.model.Character c = CharacterFactory.newCharacter(rhs, charIndex);
		context.addCharacter(c, charIndex);
	}

}
