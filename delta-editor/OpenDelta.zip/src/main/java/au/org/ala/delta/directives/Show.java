package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class Show extends Directive {

	public Show() {
		super("show");
	}

	@Override
	public void process(DeltaContext context, String data) {
		context.ErrorMessage("%s", replaceVariables(context, data.trim()));
	}

}
