package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class MandatoryCharacters extends AbstractRangeListDirective {

	public MandatoryCharacters() {
		super("mandatory", "characters");
	}

	@Override
	protected void processNumber(DeltaContext context, int number) {
		au.org.ala.delta.model.Character c = context.getCharacter(number);
		Logger.debug("Making character %d mandatory", number);
		c.setMandatory(true);
	}

}
