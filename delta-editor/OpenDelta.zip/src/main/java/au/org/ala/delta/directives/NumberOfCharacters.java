package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class NumberOfCharacters extends Directive {

	public NumberOfCharacters() {
		super("number", "of", "characters");
	}

	@Override
	public void process(DeltaContext context, String data) throws Exception {
		Logger.debug("Setting number of characters to %s", data);
		context.setNumberOfCharacters(Integer.parseInt(data));
	}

}
