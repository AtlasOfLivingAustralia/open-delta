package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class ReplaceAngleBrackets extends Directive {
	
	public ReplaceAngleBrackets() {
		super("replace", "angle", "brackets");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		context.setReplaceAngleBrackets(true);
	}
	

}
