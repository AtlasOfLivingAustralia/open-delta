package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class ExcludeCharacters extends AbstractRangeListDirective {
	
	public ExcludeCharacters() {
		super("exclude", "characters");
	}

	@Override
	protected void processNumber(DeltaContext context, int number) {
		context.excludeCharacter(number);
	}

}
