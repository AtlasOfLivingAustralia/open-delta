package au.org.ala.delta.model;

public class CharacterFactory {

	public static Character newCharacter(CharacterType type, int number) {
		switch (type) {
			case IntegerNumeric:
				return new IntegerCharacter(number);
			case OrderedMultiState:
				return new OrderedMultiStateCharacter(number);
			case RealNumeric:
				return new RealCharacter(number);
			case Text:
				return new TextCharacter(number);
			case UnorderedMultiState:
				return new UnorderedMultiStateCharacter(number);
			default:
				throw new RuntimeException("Unhandled character type: " + type);
		}
	}

}
