package au.org.ala.delta;

public class Logger {
	
	public static void log(String format, Object ...args) {
		String message = String.format(format, args);
		System.out.println(message);
	}
	
	public static void debug(String format, Object ...args) {
		String message = String.format(format, args);
		System.out.println(message);
		
	}

}
