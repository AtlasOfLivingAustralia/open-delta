package au.org.ala.delta.model;

public class StateValue {
	
	private Character _character;
	private Item _item;	
	private String _rawValue;
	private String _comment;
	
	public StateValue(Character character, Item item, String value) {
		_character = character;
		_item = item;
		_rawValue = value;
	}
	
	public Character getCharacter() {
		return _character;
	}
	
	public Item getItem() {
		return _item;
	}
	
	public String getComment() {
		return _comment;
	}
	
	public String getValue() {
		return _rawValue;		
	}
	
	public void setComment(String comment) {
		_comment = comment;
	}
	
	@Override
	public String toString() {
		return String.format("%s", _rawValue);
	}

}
