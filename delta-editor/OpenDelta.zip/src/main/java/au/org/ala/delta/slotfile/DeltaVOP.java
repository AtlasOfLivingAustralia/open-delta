package au.org.ala.delta.slotfile;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.NotImplementedException;
import org.omg.CORBA._PolicyStub;

import au.org.ala.delta.util.Utils;

public class DeltaVOP extends VOP {

	private VODeltaMasterDesc _deltaMaster;
	private VOImageInfoDesc _imageInfo;
	private Map<String, VOItemDesc> _itemNames = new HashMap<String, VOItemDesc>();

	public DeltaVOP(boolean noTemp) {
		super(noTemp);
	}

	public DeltaVOP(String filename, boolean readonly) {
		super(filename, readonly, null);
	}

	public VODeltaMasterDesc getDeltaMaster() {
		return _deltaMaster;
	}

	public VOImageInfoDesc getImageInfo() {
		return _imageInfo;
	}

	public VOItemDesc getItemFromName(String name, boolean canonical) {

		String ansiName;
		if (!canonical) {
			ansiName = Utils.stripExtraSpaces(Utils.RTFToANSI(name));
		} else {
			ansiName = name;
		}

		if (_itemNames.containsKey(ansiName)) {
			return _itemNames.get(ansiName);
		}

		return null;

	}

	public int getItemNameCount(String name) {
		return _itemNames.size();
	}

	public boolean deleteFromNameList(VOItemDesc item) {
		throw new NotImplementedException();
	}

	public void insertInNameList(VOItemDesc item) {
		_itemNames.put(item.getAnsiName(), item);
	}

	// Wrapper around Vop::Commit to also make a .bak copy of the "original" file
	public boolean commit(SlotFile slotFile) {
		if (slotFile == null) {
			slotFile = getPermSlotFile();
		}
		if (slotFile == null) {
			return false;
		}
		if (slotFile.getFileMode() == BinFileMode.FM_EXISTING) {
			String bakName = slotFile.getFileName();
			if (bakName.charAt(bakName.length() -1) != '.') {
		        bakName += '.';
			}
		    bakName += "bak";
		    try {
		          // Copy the entire contents of the original file,
		          // and its timestamp
		          BinFile bakFile = new BinFile(bakName, BinFileMode.FM_NEW);
		          slotFile.seekToEnd();
		          int size = slotFile.tell();
		          slotFile.seekToBegin();
		          bakFile.copyFile(slotFile, size);
		          
		          bakFile.setFileTime(slotFile.getFileTime());
		     }
		     catch (Exception e) {
		          //::MessageBox(NULL, "Error creating backup of data file", "File Error", MB_OK);
		    	 throw new RuntimeException(e);
		     }
		 }
		  boolean result = super.commit(slotFile);
		  // "Touch" the time stamp; otherwise the time stamp isn't updated until we
		  // finally close the file, which could lead to mis-leading times on the backup
		  // version.
		  slotFile.setFileTime(System.currentTimeMillis());
		  return result;
	}

	@Override
	protected VOAnyDesc insertDesc(VOAnyDesc aDesc) {

		VOAnyDesc desc = super.insertDesc(aDesc);
		if (desc != null) {
			if (desc.isA(VODescFactory.VODeltaMasterDesc_TypeId)) {
				if (_deltaMaster != null)
					throw new RuntimeException("Internal error! Two DELTA Master records found!");

				_deltaMaster = (VODeltaMasterDesc) desc;
			}
			if (desc.isA(VODescFactory.VOImageInfoDesc_TypeId)) {
				if (_imageInfo != null) {
					throw new RuntimeException("Internal error! Two \"Image Info\" records found!");
				}
				_imageInfo = (VOImageInfoDesc) desc;
			}
			if (desc.isA(VODescFactory.VOItemDesc_TypeId)) {
				if (_itemNames == null) {
					_itemNames = new HashMap<String, VOItemDesc>();
				}
				VOItemDesc item = (VOItemDesc) desc;
				_itemNames.put(item.getAnsiName(), item);
			}
		}
		return desc;
	}

	protected VOAnyDesc removeDesc(VOAnyDesc desc) {
		throw new NotImplementedException();
	}

	protected void killDescList() {
		throw new NotImplementedException();
	}

}
