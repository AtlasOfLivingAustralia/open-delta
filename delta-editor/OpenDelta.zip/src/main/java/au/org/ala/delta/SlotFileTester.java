package au.org.ala.delta;

import javax.swing.UIManager;

import com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel;

public class SlotFileTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// VOP v = new VOP("c:/zz/bigtest.dlt", true);
		// DeltaVOP v = new DeltaVOP("c:/zz/sample.dlt", true);
		// v.close();
		
		try {
			UIManager.setLookAndFeel(new WindowsClassicLookAndFeel());
			//UIManager.setLookAndFeel(new WindowsLookAndFeel());
// 			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception ex) {
			System.err.println(ex);
		}

		DeltaContext context = DeltaFileReader.readDeltaFile("c:/zz/grasses.dlt");

		MatrixViewer grid = new MatrixViewer(context);
		grid.setVisible(true);
		
		TreeViewer tree = new TreeViewer(context);
		tree.setVisible(true);

	}

}
