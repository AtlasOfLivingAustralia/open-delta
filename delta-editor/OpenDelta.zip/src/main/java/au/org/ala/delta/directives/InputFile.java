package au.org.ala.delta.directives;

import java.io.File;
import java.io.FileNotFoundException;

import au.org.ala.delta.DeltaContext;

public class InputFile extends Directive {

	public InputFile() {
		super("input", "file");
	}

	@Override
	public void process(DeltaContext context, String data) {
		
		File file = new File(context.getCurrentParsingContext().getFile().getParent(), data.trim());
		 
		try {
			if (file.exists()) {				
				new DirectiveFileParser().parse(file, context);				
			} else {
				throw new FileNotFoundException(data);
			}
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}

	}

}
