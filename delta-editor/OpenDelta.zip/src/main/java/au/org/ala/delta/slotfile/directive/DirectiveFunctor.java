package au.org.ala.delta.slotfile.directive;


public interface DirectiveFunctor {
	void process(DirectiveInOutState state);
}
