package au.org.ala.delta.slotfile.directive;

public class DirectiveInOutState {

}
