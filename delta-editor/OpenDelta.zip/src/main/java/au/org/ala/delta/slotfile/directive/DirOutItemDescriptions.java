package au.org.ala.delta.slotfile.directive;

import org.apache.commons.lang.NotImplementedException;

public class DirOutItemDescriptions implements DirectiveFunctor {

	@Override
	public void process(DirectiveInOutState state) {
		throw new NotImplementedException();
	}

}
