package au.org.ala.delta.slotfile;

public interface INameHolder {
	
	String getAnsiName();

}
