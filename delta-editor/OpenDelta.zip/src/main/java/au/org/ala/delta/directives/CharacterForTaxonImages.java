package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class CharacterForTaxonImages extends Directive {
	
	public CharacterForTaxonImages() {
		super("character", "for", "taxon", "images");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		context.setCharacterForTaxonImages(Integer.parseInt(data));
	}

}
