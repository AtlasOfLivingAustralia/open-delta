package au.org.ala.delta.slotfile;

public class CharType {
	public static final int UNKNOWN = 0;
	public static final int UNORDERED = 1;
	public static final int ORDERED = 2;
	public static final int INTEGER = 3;
	public static final int REAL = 4;
	public static final int TEXT = 5;
	public static final int LIST = 6;
	public static final int CYCLIC = 7;
	public static final int LISTEND = 8;
	
	public static boolean isNumeric(int type) {
		return (type == CharType.INTEGER || type == CharType.REAL);
	}

	public static boolean isMultistate(int type) {
		return (type == CharType.UNORDERED || type == CharType.ORDERED || type == CharType.LIST || type == CharType.CYCLIC);
	}

	public static boolean isText(int type) {
		return (type == CharType.TEXT);
	}

}
