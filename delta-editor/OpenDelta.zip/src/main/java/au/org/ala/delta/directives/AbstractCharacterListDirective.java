package au.org.ala.delta.directives;

import java.util.regex.Pattern;

import org.apache.commons.lang.math.IntRange;

import au.org.ala.delta.DeltaContext;

public abstract class AbstractCharacterListDirective<T> extends Directive {

	private static Pattern CHAR_LIST_ITEM_PATTERN = Pattern.compile("^(\\d+),(.*)$|^(\\d+[-]\\d+),(.*)$");

	public AbstractCharacterListDirective(String... controlWords) {
		super(controlWords);
	}

	@Override
	public void process(DeltaContext context, String data) throws Exception {
		String[] typeDescriptors = data.split(" |\\n");
		for (String typeDescriptor : typeDescriptors) {
			typeDescriptor = typeDescriptor.trim();
			if (CHAR_LIST_ITEM_PATTERN.matcher(typeDescriptor).matches()) {
				String[] bits = typeDescriptor.trim().split(",");
				IntRange r = parseRange(bits[0]);
				T rhs = interpretRHS(context, bits[1]);
				for (int charIndex = r.getMinimumInteger(); charIndex <= r.getMaximumInteger(); ++charIndex) {
					processCharacter(context, charIndex, rhs);
				}
			}
		}
	}

	protected abstract T interpretRHS(DeltaContext context, String rhs);

	protected abstract void processCharacter(DeltaContext context, int charIndex, T rhs);

}
