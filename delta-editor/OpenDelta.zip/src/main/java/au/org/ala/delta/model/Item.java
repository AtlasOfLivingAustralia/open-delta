package au.org.ala.delta.model;

import org.apache.commons.lang.NotImplementedException;

public class Item {


	private int _itemId;
	private String _description;
	
	public Item(int itemId) {
		_itemId = itemId;
	}
	
	public int getItemId() {
		return _itemId;
	}

	public void setDescription(String itemName) {
		_description = itemName;
	}
	
	public String getDescription() {
		return _description;
	}
	
	public void setAttribute(Character character, String value) {
		throw new NotImplementedException();
	}
}
