/***************************************************************************
 * Acknowledgements
 * The contents of this file have been derived from the original DELTA 
 * software source code:  
 *   Intkey: Dallwitz 1980; Dallwitz, Paine, and Zurcher 1993; Dallwitz, Paine, and Zurcher 1995; Dallwitz, Paine, and Zurcher 2000.
 *   DELTA format, Confor, Dist, Intimate: Dallwitz 1980; Dallwitz, Paine, and Zurcher 1993.
 *   Key: Dallwitz 1974; Dallwitz 1980; Dallwitz, Paine, and Zurcher 1993.
 *   DELTA Editor: Dallwitz 1980; Dallwitz, Paine, and Zurcher 1999.   
 * Please see http://delta-intkey.com for more information.
 * 
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 ***************************************************************************/

package au.org.ala.delta.model;

/**
 * @author god08d
 *
 */
public class DeltaDataSet {

}
