package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class PrintWidth extends Directive {
	
	public PrintWidth() {
		super("print", "width");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		Logger.debug("Setting the print width to %s", data);
		context.setPrintWidth(Integer.parseInt(data));
	}

}
