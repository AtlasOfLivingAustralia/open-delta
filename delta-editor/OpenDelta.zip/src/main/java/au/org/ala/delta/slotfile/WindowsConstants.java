package au.org.ala.delta.slotfile;

public interface WindowsConstants {
	
	int MAX_PATH = 260;
	
}
