package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class NewParagraphAtCharacters extends AbstractRangeListDirective {
	
	public NewParagraphAtCharacters() {
		super("new", "paragraph", "at", "characters");		
	}

	@Override
	protected void processNumber(DeltaContext context, int number) {
		context.newParagraphAtCharacter(number);
	}

}
