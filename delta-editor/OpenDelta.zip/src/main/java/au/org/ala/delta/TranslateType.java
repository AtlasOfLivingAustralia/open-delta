package au.org.ala.delta;

public enum TranslateType {
	
	Delta,
	Dist,
	Hennig86,
	IntKey,
	Key,
	NaturalLanguage,
	NexusFormat,
	PAUP,
	Payne,
	Alice,
	EXIR

}
