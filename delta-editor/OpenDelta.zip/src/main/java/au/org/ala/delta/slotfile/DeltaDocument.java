package au.org.ala.delta.slotfile;

public class DeltaDocument {

}
