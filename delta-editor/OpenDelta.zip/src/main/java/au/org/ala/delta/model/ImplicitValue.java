package au.org.ala.delta.model;

public class ImplicitValue {
	
	private Integer _t;
	private Integer _s;
	
	public ImplicitValue() {		
	}
	
	public void setCoded(Integer t) {
		_t = t;
	}
	
	public void setUncoded(Integer s) {
		_s = s;
	}
	
	public Integer getCoded() {
		return _t;		
	}
	
	public Integer getUncoded() {
		return _s;
	}
	
	@Override
	public String toString() {
		return String.format("s (uncoded)=%s, t (coded)=%s", _s, _t);
	}

}
