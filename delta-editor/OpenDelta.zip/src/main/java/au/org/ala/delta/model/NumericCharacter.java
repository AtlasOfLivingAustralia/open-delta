package au.org.ala.delta.model;

public abstract class NumericCharacter<T extends Number> extends Character{
	
	private String _units;

	public NumericCharacter(int number) {
		super(number);
	}
	
	public String getUnits() {
		return _units;
	}
	
	public void setUnits(String units) {
		_units = units;
	}

}
