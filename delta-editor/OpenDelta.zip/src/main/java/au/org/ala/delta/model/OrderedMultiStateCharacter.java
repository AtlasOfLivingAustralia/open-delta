package au.org.ala.delta.model;

public class OrderedMultiStateCharacter extends MultiStateCharacter {

	public OrderedMultiStateCharacter(int number) {
		super(number);
	}

}
