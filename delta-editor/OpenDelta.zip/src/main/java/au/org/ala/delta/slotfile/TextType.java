package au.org.ala.delta.slotfile;

public enum TextType {
	  ANSI,
	  RTF,
	  UTF8
}
