package au.org.ala.delta.slotfile;

public enum SeekDirection {
	FROM_BEG,
	FROM_CUR,
	FROM_END
}
