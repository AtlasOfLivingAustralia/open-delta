package au.org.ala.delta.slotfile;

public class ImageType {
	
	  public static final int IMAGE_UNKNOWN = -1;
	  
	  public static final int IMAGE_TAXON = 0;
	  public static final int IMAGE_CHARACTER = 1;
	  public static final int IMAGE_STARTUP = 2;
	  public static final int IMAGE_TAXON_KEYWORD = 3;
	  public static final int IMAGE_CHARACTER_KEYWORD = 4;
	  
}
