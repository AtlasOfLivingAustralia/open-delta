package au.org.ala.delta.directives;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.math.IntRange;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;
import au.org.ala.delta.model.CharacterDependency;
import au.org.ala.delta.util.IntegerFunctor;

public class DependentCharacters extends AbstractCharacterListDirective<String> {

	public DependentCharacters() {
		super("dependent", "characters");
	}

	@Override
	protected String interpretRHS(DeltaContext context, String rhs) {
		return rhs;
	}

	@Override
	protected void processCharacter(DeltaContext context, final int charIndex, String rhs) {
		// Dependencies take the form <c>,<s>:<d>. rhs == <s>:<d>
		// <s> = a set of state ids separated by "/"
		// <d> is a set of character ids separated by : and can include ranges
		// (n-n)

		final au.org.ala.delta.model.Character ch = context.getCharacter(charIndex);
		final Set<Integer> states = new HashSet<Integer>();
		String stateSet = rhs.substring(0, rhs.indexOf(":"));
		String[] stateIds = stateSet.split("/");
		for (String stateId : stateIds) {
			states.add(Integer.parseInt(stateId));
		}

		String charSet = rhs.substring(rhs.indexOf(":") + 1);
		String[] charBits = charSet.split(":");
		for (String charBit : charBits) {
			IntRange r = parseRange(charBit);
			forEach(r, context, new IntegerFunctor() {
				@Override
				public void invoke(DeltaContext context, int arg) {
					CharacterDependency d = new CharacterDependency(charIndex, states, arg);
					Logger.debug("Character dependency: %s", d);
					ch.addDependentCharacter(d);
				}
			});
		}

	}

}
