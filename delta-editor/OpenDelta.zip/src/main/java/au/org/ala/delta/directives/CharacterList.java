package au.org.ala.delta.directives;

import java.io.Reader;
import java.io.StringReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.model.MultiStateCharacter;
import au.org.ala.delta.model.NumericCharacter;

public class CharacterList extends Directive {

	public CharacterList() {
		super("character", "list");
	}

	@Override
	public void process(DeltaContext context, String data) throws Exception {
		StringReader reader = new StringReader(data);
		CharacterListParser parser = new CharacterListParser(context, reader);
		parser.parse();
	}

}

class CharacterListParser extends AbstractStreamParser {

	private static Pattern FEAT_DESC_PATTERN = Pattern.compile("^(\\d+)\\s*[.] (.*)$", Pattern.DOTALL);

	public CharacterListParser(DeltaContext context, Reader reader) {
		super(context, reader);
	}

	public void parse() throws Exception {
		while (skipTo('#')) {
			// parseCharacter will consume all characters up until the last / of
			// the feature description or last state,
			parseCharacter();
		}
	}

	private void parseCharacter() throws Exception {
		// Current char should be '#'
		assert _currentChar == '#';
		// read the next character
		readNext();
		
		String desc = readToNextEndSlashSpace();
		Matcher m = FEAT_DESC_PATTERN.matcher(desc);

		if (m.matches()) {
			int charId = Integer.parseInt(m.group(1));
			au.org.ala.delta.model.Character ch = _context.getCharacter(charId);
			ch.setDescription(m.group(2));
			if (skipWhitespace()) {
				if (_currentChar != '#') {
					if (ch instanceof MultiStateCharacter) {
						boolean haveStates = java.lang.Character.isDigit(_currentChar);
						while (haveStates) {
							parseState((MultiStateCharacter) ch);
							skipWhitespace();
							haveStates = java.lang.Character.isDigit(_currentChar);
						}
					} else if (ch instanceof NumericCharacter) {
						// we might see a units descriptor...
						@SuppressWarnings("rawtypes")
						NumericCharacter nc = (NumericCharacter) ch;
						String units = _currentChar + readToNextEndSlashSpace();
						nc.setUnits(units);
					}
				} else {
					if (ch instanceof MultiStateCharacter) {
						MultiStateCharacter msc = (MultiStateCharacter) ch;
						if (msc.getNumberOfStates() > 0) {
							throw new RuntimeException("Expected " + msc.getNumberOfStates() + " states for character " + ch.getCharacterId() + ". Found none!");
						}

					}
				}
			}
		} else {
			throw new IllegalStateException("Invalid character feature description: " + desc);
		}

	}

	private void parseState(MultiStateCharacter ch) throws Exception {
		String state = readToNextEndSlashSpace();
		Matcher m = FEAT_DESC_PATTERN.matcher(state);
		if (m.matches()) {
			int stateId = Integer.parseInt(m.group(1));
			ch.setState(stateId, m.group(2));
		} else {
			throw new IllegalStateException("State does not match expected format!:" + state);
		}
	}

}
