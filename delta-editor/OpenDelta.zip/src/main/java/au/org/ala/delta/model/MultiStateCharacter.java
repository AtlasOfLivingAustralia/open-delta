package au.org.ala.delta.model;

public abstract class MultiStateCharacter extends Character {

	private int _numberOfStates;
	private String[] _states;
	private ImplicitValue _implicitValueStateId;

	public MultiStateCharacter(int number) {
		super(number);
	}

	public int getNumberOfStates() {
		return _numberOfStates;
	}

	public void setNumberOfStates(int states) {
		_numberOfStates = states;
		_states = new String[_numberOfStates];
	}

	public String[] getStates() {
		return _states;
	}

	public void setImplicitValueStateId(ImplicitValue value) {
		_implicitValueStateId = value;
	}

	public ImplicitValue getImplicitValueStateId() {
		return _implicitValueStateId;
	}

	public void setState(int stateId, String state) {
		// TODO bounds check!
		_states[stateId - 1] = state;
	}

	public String getState(int stateId) {
		return _states[stateId - 1];
	}

}
