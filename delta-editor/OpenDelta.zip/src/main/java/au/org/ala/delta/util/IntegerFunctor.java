package au.org.ala.delta.util;

import au.org.ala.delta.DeltaContext;

public interface IntegerFunctor {
	
	void invoke(DeltaContext context, int arg);

}
