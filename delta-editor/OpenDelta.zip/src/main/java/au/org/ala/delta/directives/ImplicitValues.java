package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;
import au.org.ala.delta.model.Character;
import au.org.ala.delta.model.ImplicitValue;
import au.org.ala.delta.model.MultiStateCharacter;

public class ImplicitValues extends AbstractCharacterListDirective<ImplicitValue> {
	
	public ImplicitValues() {
		super("implicit", "values");
	}

	@Override
	protected ImplicitValue interpretRHS(DeltaContext context, String rhs) {
		ImplicitValue ret = new ImplicitValue();
		if (rhs.contains(":")) {
			String bits[] = rhs.split(":");
			ret.setUncoded(Integer.parseInt(bits[0]));
			ret.setCoded(Integer.parseInt(bits[1]));
		} else {
			ret.setUncoded(Integer.parseInt(rhs));
		}
		return ret;
	}

	@Override
	protected void processCharacter(DeltaContext context, int charIndex, ImplicitValue rhs) {
		Character c = context.getCharacter(charIndex);
		if (c instanceof MultiStateCharacter) {
			Logger.debug("Setting implicit value for character %d: %s", charIndex, rhs);
			MultiStateCharacter msc = (MultiStateCharacter) c;
			msc.setImplicitValueStateId(rhs);
		} else {
			throw new RuntimeException("Attempted to set implicit values for non-multistate character: " + charIndex);
		}
	}

}
