package au.org.ala.delta.slotfile;

import au.org.ala.delta.slotfile.directive.DirectiveFunctor;

public class Directive {
	
	private String[] _name;
	private int _level;
	private int _number;
	private int _argType;
	private DirectiveFunctor _inFunc;
	private DirectiveFunctor _outFunc;
	
	public Directive(String[] name, int level, int number, int argType, DirectiveFunctor inFunc, DirectiveFunctor outFunc) {
		_name = name;
		_level = level;
		_number = number;
		_argType = argType;
		_inFunc = inFunc;
		_outFunc = outFunc;
	}
	
	public String[] getName() {
		return _name;
	}
	
	public int getLevel() {
		return _level;
	}
	
	public int getNumber() {
		return _number;
	}
	
	public int getArgType() {
		return _argType;
	}
	
	public DirectiveFunctor getInFunc() {
		return _inFunc;
	}
	
	public DirectiveFunctor getOutFunc() {
		return _outFunc;
	}

}
