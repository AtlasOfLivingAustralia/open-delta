package au.org.ala.delta.directives;

public class DataBufferSize extends NoopDirective {
	
	public DataBufferSize() {
		super("data", "buffer", "size");
	}

}
