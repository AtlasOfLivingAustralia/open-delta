package au.org.ala.delta;

public interface IContextHolder {
	
	DeltaContext getContext();

}
