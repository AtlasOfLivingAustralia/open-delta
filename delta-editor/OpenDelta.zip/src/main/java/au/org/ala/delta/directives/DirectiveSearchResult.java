package au.org.ala.delta.directives;


public class DirectiveSearchResult {

	public enum ResultType {
		Found, NotFound, MoreSpecificityRequired
	}

	private ResultType _resultType;
	private Directive _directive;

	public DirectiveSearchResult(ResultType resultType, Directive directive) {
		this._resultType = resultType;
		this._directive = directive;
	}

	public ResultType getResultType() {
		return _resultType;
	}

	public Directive getDirective() {
		return _directive;
	}

}
