package au.org.ala.delta.slotfile;

public interface IOObject {

	void read(BinFile file);
	
	void write(BinFile file);
	
}
