package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;
import au.org.ala.delta.model.MultiStateCharacter;

public class NumbersOfStates extends AbstractCharacterListDirective<Integer> {
	
	public NumbersOfStates() {
		super("numbers", "of", "states");
	}

	@Override
	protected Integer interpretRHS(DeltaContext context, String rhs) {
		return Integer.parseInt(rhs);
	}

	@Override
	protected void processCharacter(DeltaContext context, int charIndex, Integer rhs) {
		au.org.ala.delta.model.Character ch = context.getCharacter(charIndex);
		if (ch == null) {
			throw new RuntimeException("Attempt to set number of states on an undefined character: " + charIndex);
		}
		if (ch instanceof MultiStateCharacter) {
			Logger.debug("Setting number of states on character %d to %d", charIndex, rhs);			
			MultiStateCharacter msch = (MultiStateCharacter) ch;
			msch.setNumberOfStates(rhs);
		} else {
			throw new RuntimeException("Attempt to set number of states on an non-multistate character: " + charIndex);
		}
	}

}
