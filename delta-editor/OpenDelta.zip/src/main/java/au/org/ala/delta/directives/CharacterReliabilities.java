package au.org.ala.delta.directives;

public class CharacterReliabilities extends Directive {

	public CharacterReliabilities() {
		super("character", "reliabilities");
	}

}
