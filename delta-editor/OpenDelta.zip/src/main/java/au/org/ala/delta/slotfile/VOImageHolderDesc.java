package au.org.ala.delta.slotfile;

import java.util.List;

public abstract class VOImageHolderDesc extends VOAnyDesc {

	public VOImageHolderDesc(SlotFile slotFile, VOP vop) {
		super(slotFile, vop);
	}

	@Override
	public int getTypeId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getStringId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getNumberOfItems() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public abstract List<Integer> readImageList();
	
	public abstract boolean writeImageList(List<Integer> imagelist);
	
	public abstract int getImageType();

}
