package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public abstract class NoopDirective extends Directive {
	
	public NoopDirective(String ...controlwords) {
		super(controlwords);
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		// Do nothing - deprecated directive
	}

}
