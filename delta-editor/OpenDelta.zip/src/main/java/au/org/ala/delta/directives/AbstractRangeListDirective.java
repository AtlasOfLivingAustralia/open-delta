package au.org.ala.delta.directives;

import org.apache.commons.lang.math.IntRange;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.util.IntegerFunctor;

public abstract class AbstractRangeListDirective extends Directive {
	
	protected AbstractRangeListDirective(String ...controlWords) {
		super(controlWords);
	}

	@Override
	public void process(DeltaContext context, String data) throws Exception {
		// data is a space separate list of ranges...
		String[] ranges = data.split(" ");
		for (String range : ranges) {
			IntRange r = parseRange(range);
			forEach(r, context, new IntegerFunctor() {
				@Override
				public void invoke(DeltaContext context, int number) {
					processNumber(context, number);
				}
			});
		}

	}

	protected abstract void processNumber(DeltaContext context, int number);

}
