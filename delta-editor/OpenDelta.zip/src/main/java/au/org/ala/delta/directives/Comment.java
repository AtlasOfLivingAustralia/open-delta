package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class Comment extends Directive {
	
	public Comment() {
		super("comment");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		Logger.debug("Comment: %s", data);
	}

}
