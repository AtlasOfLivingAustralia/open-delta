package au.org.ala.delta;

import java.io.File;
import java.io.IOException;

import au.org.ala.delta.directives.DirectiveFileParser;

public class CONFOR {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {

		DirectiveFileParser.DIRECTIVE_TREE.dump();

		//String filename = "C:\\Users\\baird\\Dev\\Backup of M. Dallwitz computer, 23 jan 2001  (archive only)\\Drive D\\delta\\sample\\tonat";
		String filename = "c:\\delta\test\\tokey";
		File f = new File(filename);
		if (!f.exists()) {
			Logger.log("File %s does not exist!", filename);
			return;
		}

		DeltaContext context = new DeltaContext();
		
		StringBuilder credits = new StringBuilder("CONFOR version 3.00 (Java)");
		credits.append("\n\nM. J. Dallwitz, T.A. Paine and E.J. Zurcher");
		credits.append("\n\nCSIRO Division of Entomology, GPO Box 1700, Canberra, ACT 2601, Australia\nPhone +61 2 6246 4075. Fax +61 2 6246 4000. Email delta@ento.csiro.au");
		credits.append("\n\nJava edition ported by the Atlas of Living Australia, 2010.\n");
		
		context.setCredits(credits.toString());
		
		Logger.log("%s", context.getCredits());

		DirectiveFileParser p = new DirectiveFileParser();
		p.parse(f, context);
		
		MatrixViewer viewer = new MatrixViewer(context);
		viewer.setVisible(true);
	}

}
