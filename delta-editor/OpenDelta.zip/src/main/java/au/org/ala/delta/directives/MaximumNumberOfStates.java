package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;
import au.org.ala.delta.Logger;

public class MaximumNumberOfStates extends Directive {
	
	public MaximumNumberOfStates() {
		super("maximum", "number", "of", "states");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {	
		Logger.debug("Setting max number of states to %s", data);
		context.setMaximumNumberOfStates(Integer.parseInt(data));
	}

}
