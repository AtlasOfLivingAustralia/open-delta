package au.org.ala.delta.directives;

import au.org.ala.delta.DeltaContext;

public class OmitCharacterNumbers extends Directive {
	
	public OmitCharacterNumbers() {
		super("omit", "character", "numbers");
	}
	
	@Override
	public void process(DeltaContext context, String data) throws Exception {
		context.setOmitCharacterNumbers(true);
	}

}
