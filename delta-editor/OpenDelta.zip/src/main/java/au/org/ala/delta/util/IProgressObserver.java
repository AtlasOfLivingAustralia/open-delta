package au.org.ala.delta.util;

public interface IProgressObserver {

	void progress(String message, int percentComplete);
}
