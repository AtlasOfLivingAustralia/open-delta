package au.org.ala.delta.slotfile;

public enum BinFileMode {
	FM_NEW, FM_EXISTING, FM_APPEND, FM_TEMPORARY, FM_READONLY
}