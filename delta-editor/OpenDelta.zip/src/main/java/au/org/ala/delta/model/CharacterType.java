package au.org.ala.delta.model;

import java.util.HashMap;

public enum CharacterType {	
	Text,
	IntegerNumeric,
	RealNumeric,
	OrderedMultiState,
	UnorderedMultiState;
	
	public static CharacterType parse(String str) {
		String s = str.substring(0,2).toUpperCase();
		if (TYPE_MAP.containsKey(s)) {
			return TYPE_MAP.get(s);
		}
		throw new RuntimeException("Unrecognized character type literal: " + str);
	}
	
	private static HashMap<String, CharacterType> TYPE_MAP = new HashMap<String, CharacterType>();
	
	static {
		TYPE_MAP.put("TE", Text);
		TYPE_MAP.put("IN", IntegerNumeric);
		TYPE_MAP.put("RN", RealNumeric);
		TYPE_MAP.put("OM", OrderedMultiState);
		TYPE_MAP.put("UM", UnorderedMultiState);
	}
}
